using System.IO;
using GlowNest.AR;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.XR.ARFoundation;

namespace GlowNest.AR.Editor
{
    public static class GlowNestSceneBuilder
    {
        private const string ScenePath = "Assets/Scenes/GlowNestAR.unity";

        [MenuItem("GlowNest/Build AR Scene")]
        public static void BuildScene()
        {
            EnsureFolder("Assets/Scenes");

            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            scene.name = "GlowNestAR";

            GameObject arSession = new("AR Session");
            arSession.AddComponent<ARSession>();

            GameObject xrOrigin = new("XR Origin");
            XROrigin origin = xrOrigin.AddComponent<XROrigin>();
            ARRaycastManager raycastManager = xrOrigin.AddComponent<ARRaycastManager>();
            ARPlaneManager planeManager = xrOrigin.AddComponent<ARPlaneManager>();
            ARAnchorManager anchorManager = xrOrigin.AddComponent<ARAnchorManager>();
            ARPlacementController placementController = xrOrigin.AddComponent<ARPlacementController>();

            GameObject cameraOffset = new("Camera Offset");
            cameraOffset.transform.SetParent(xrOrigin.transform, false);
            origin.CameraFloorOffsetObject = cameraOffset;

            GameObject cameraObject = new("AR Camera");
            cameraObject.transform.SetParent(cameraOffset.transform, false);
            Camera camera = cameraObject.AddComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = Color.black;
            camera.nearClipPlane = 0.05f;
            camera.farClipPlane = 80f;
            cameraObject.AddComponent<ARCameraManager>();
            cameraObject.AddComponent<ARCameraBackground>();
            origin.Camera = camera;

            GameObject catalogObject = new("Product Catalog");
            ProductModelLibrary modelLibrary = catalogObject.AddComponent<ProductModelLibrary>();
            ProductCatalog catalog = catalogObject.AddComponent<ProductCatalog>();

            GameObject reticleObject = BuildReticle();
            SurfaceReticle reticle = reticleObject.AddComponent<SurfaceReticle>();

            SerializedObject placement = new(placementController);
            placement.FindProperty("arCamera").objectReferenceValue = camera;
            placement.FindProperty("catalog").objectReferenceValue = catalog;
            placement.FindProperty("planeManager").objectReferenceValue = planeManager;
            placement.FindProperty("anchorManager").objectReferenceValue = anchorManager;
            placement.FindProperty("reticle").objectReferenceValue = reticle;
            placement.ApplyModifiedPropertiesWithoutUndo();

            SerializedObject catalogSerialized = new(catalog);
            catalogSerialized.FindProperty("modelLibrary").objectReferenceValue = modelLibrary;
            catalogSerialized.ApplyModifiedPropertiesWithoutUndo();

            SerializedObject reticleSerialized = new(reticle);
            reticleSerialized.FindProperty("ring").objectReferenceValue = reticleObject.transform.Find("Ring");
            reticleSerialized.FindProperty("wallMarker").objectReferenceValue = reticleObject.transform.Find("Wall Marker");
            reticleSerialized.FindProperty("ceilingMarker").objectReferenceValue = reticleObject.transform.Find("Ceiling Marker");
            reticleSerialized.ApplyModifiedPropertiesWithoutUndo();

            GameObject light = new("Directional Light");
            Light directional = light.AddComponent<Light>();
            directional.type = LightType.Directional;
            directional.intensity = 1.1f;
            light.transform.rotation = Quaternion.Euler(45f, -30f, 0f);

            EditorSceneManager.SaveScene(scene, ScenePath);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            EditorUtility.DisplayDialog(
                "GlowNest AR Scene Built",
                "Created Assets/Scenes/GlowNestAR.unity. Add real product prefabs later, then build to Android or iOS.",
                "OK"
            );
        }

        [MenuItem("GlowNest/Open Build Checklist")]
        public static void OpenChecklist()
        {
            Object checklist = AssetDatabase.LoadAssetAtPath<Object>("Assets/Scripts/BuildChecklist.md");
            if (checklist != null)
                AssetDatabase.OpenAsset(checklist);
        }

        private static GameObject BuildReticle()
        {
            GameObject root = new("Surface Reticle");
            root.SetActive(false);

            GameObject ring = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            ring.name = "Ring";
            ring.transform.SetParent(root.transform, false);
            ring.transform.localScale = new Vector3(0.18f, 0.004f, 0.18f);
            Object.DestroyImmediate(ring.GetComponent<Collider>());

            GameObject wall = GameObject.CreatePrimitive(PrimitiveType.Cube);
            wall.name = "Wall Marker";
            wall.transform.SetParent(root.transform, false);
            wall.transform.localScale = new Vector3(0.22f, 0.22f, 0.01f);
            Object.DestroyImmediate(wall.GetComponent<Collider>());

            GameObject ceiling = GameObject.CreatePrimitive(PrimitiveType.Cube);
            ceiling.name = "Ceiling Marker";
            ceiling.transform.SetParent(root.transform, false);
            ceiling.transform.localScale = new Vector3(0.22f, 0.01f, 0.22f);
            Object.DestroyImmediate(ceiling.GetComponent<Collider>());

            return root;
        }

        private static void EnsureFolder(string folder)
        {
            if (AssetDatabase.IsValidFolder(folder))
                return;

            string parent = Path.GetDirectoryName(folder)?.Replace("\\", "/");
            string name = Path.GetFileName(folder);
            if (!string.IsNullOrEmpty(parent) && !AssetDatabase.IsValidFolder(parent))
                EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, name);
        }
    }
}

