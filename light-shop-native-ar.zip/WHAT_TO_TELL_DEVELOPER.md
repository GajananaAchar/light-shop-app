# What To Tell A Developer

Build a native AR mobile app for a lights shop.

The customer must browse the product catalog and preview lights in their real home using the phone camera. The light must not be a screen sticker. It must attach to a detected AR wall or ceiling plane and remain fixed in world space after placement.

Required tech:

- Unity 2022 LTS
- AR Foundation
- ARKit XR Plugin
- ARCore XR Plugin
- Real 3D fixture models
- World anchors
- Plane filtering

Placement rules:

- Wall products place only on vertical planes.
- Ceiling products place only on upper horizontal planes.
- Placed object stays anchored even when phone moves.
- Product scale uses real meters.
- Object pivot must match the physical mounting point.

The current website is only a concept demo. The perfect version must be this native AR app.

