# Unity Scene Checklist

Create one scene named `GlowNestAR`.

Add these objects:

1. `AR Session`
2. `XR Origin`
3. `AR Camera`
4. `ARRaycastManager` on `XR Origin`
5. `ARPlaneManager` on `XR Origin`
6. `ARAnchorManager` on `XR Origin`
7. `ProductCatalog`
8. `ProductModelLibrary`
9. `ARPlacementController`
10. `SurfaceReticle`

Connect references in the Inspector:

- `ARPlacementController.arCamera` -> AR Camera
- `ARPlacementController.catalog` -> ProductCatalog
- `ARPlacementController.planeManager` -> ARPlaneManager
- `ARPlacementController.anchorManager` -> ARAnchorManager
- `ARPlacementController.reticle` -> SurfaceReticle
- `ProductCatalog.modelLibrary` -> ProductModelLibrary

Build settings:

- iOS: enable ARKit, camera usage description.
- Android: enable ARCore, minimum API 24 or higher, camera permission.

