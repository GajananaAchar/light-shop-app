using System;
using System.Collections.Generic;
using UnityEngine;

namespace GlowNest.AR
{
    [Serializable]
    public class ProductPrefabEntry
    {
        public string modelId;
        public GameObject prefab;
    }

    public class ProductModelLibrary : MonoBehaviour
    {
        [SerializeField] private List<ProductPrefabEntry> prefabs = new();
        [SerializeField] private Material wallLightMaterial;
        [SerializeField] private Material ceilingLightMaterial;
        [SerializeField] private Material glowMaterial;

        public GameObject CreateModel(LightProduct product)
        {
            ProductPrefabEntry entry = prefabs.Find(item => item.modelId == product.model && item.prefab != null);
            if (entry != null)
                return Instantiate(entry.prefab);

            return CreateProceduralPlaceholder(product);
        }

        private GameObject CreateProceduralPlaceholder(LightProduct product)
        {
            GameObject root = new GameObject(product.name);
            root.transform.localScale = Vector3.one;

            switch (product.MountType)
            {
                case MountType.Wall:
                    BuildWallSconce(root, product);
                    break;
                case MountType.Strip:
                    BuildStrip(root, product);
                    break;
                default:
                    BuildCeilingLight(root, product);
                    break;
            }

            return root;
        }

        private void BuildWallSconce(GameObject root, LightProduct product)
        {
            AddCube(root.transform, "Back plate", new Vector3(0f, 0f, 0f), new Vector3(0.16f, 0.52f, 0.04f), wallLightMaterial);
            AddCube(root.transform, "Warm top glow", new Vector3(0f, 0.18f, -0.03f), new Vector3(0.09f, 0.24f, 0.035f), glowMaterial);
            AddCube(root.transform, "Warm bottom glow", new Vector3(0f, -0.18f, -0.03f), new Vector3(0.09f, 0.24f, 0.035f), glowMaterial);
        }

        private void BuildCeilingLight(GameObject root, LightProduct product)
        {
            AddCube(root.transform, "Canopy", new Vector3(0f, 0.12f, 0f), new Vector3(0.16f, 0.04f, 0.16f), ceilingLightMaterial);
            AddCube(root.transform, "Stem", new Vector3(0f, -0.06f, 0f), new Vector3(0.035f, 0.32f, 0.035f), ceilingLightMaterial);
            AddCube(root.transform, "Warm diffuser", new Vector3(0f, -0.28f, 0f), new Vector3(product.widthMeters, 0.08f, product.widthMeters), glowMaterial);
        }

        private void BuildStrip(GameObject root, LightProduct product)
        {
            AddCube(root.transform, "LED strip", Vector3.zero, new Vector3(product.widthMeters, 0.035f, 0.04f), glowMaterial);
        }

        private void AddCube(Transform parent, string name, Vector3 position, Vector3 scale, Material material)
        {
            GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
            cube.name = name;
            cube.transform.SetParent(parent, false);
            cube.transform.localPosition = position;
            cube.transform.localScale = scale;

            if (material != null && cube.TryGetComponent(out MeshRenderer renderer))
                renderer.sharedMaterial = material;
        }
    }
}

