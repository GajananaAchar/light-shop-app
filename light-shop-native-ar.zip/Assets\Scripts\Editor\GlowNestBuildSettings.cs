using UnityEditor;
using UnityEditor.XR.Management;
using UnityEngine;

namespace GlowNest.AR.Editor
{
    public static class GlowNestBuildSettings
    {
        [MenuItem("GlowNest/Configure Android Build Notes")]
        public static void ConfigureAndroidNotes()
        {
            PlayerSettings.companyName = "GlowNest";
            PlayerSettings.productName = "GlowNest Lights";
            PlayerSettings.applicationIdentifier = "com.glownest.lightsar";
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.Android.ARCoreEnabled = true;

            EditorUtility.DisplayDialog(
                "Android Settings Applied",
                "Android package name and ARCore settings were applied. In Project Settings > XR Plug-in Management, enable ARCore for Android.",
                "OK"
            );
        }

        [MenuItem("GlowNest/Configure iOS Build Notes")]
        public static void ConfigureIosNotes()
        {
            PlayerSettings.companyName = "GlowNest";
            PlayerSettings.productName = "GlowNest Lights";
            PlayerSettings.applicationIdentifier = "com.glownest.lightsar";
            PlayerSettings.iOS.cameraUsageDescription = "GlowNest uses the camera to preview lights on real walls and ceilings.";
            PlayerSettings.iOS.targetOSVersionString = "14.0";

            EditorUtility.DisplayDialog(
                "iOS Settings Applied",
                "iOS bundle ID and camera permission text were applied. On macOS, enable ARKit in XR Plug-in Management, then export to Xcode.",
                "OK"
            );
        }
    }
}

