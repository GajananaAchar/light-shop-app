# Testing Guide

## Devices

Use real phones. AR cannot be trusted from a desktop browser or simulator.

Recommended:

- iPhone 12 or newer
- Android phone with ARCore support

## Test Room

Use a room with visible wall texture, corners, shelves, frames, or patterns. Pure plain white walls are harder for any AR system to map.

## Test Flow

1. Open the app.
2. Select `Opal Wall Sconce`.
3. Move the phone slowly so AR detects wall planes.
4. Aim at a wall.
5. Place the light.
6. Walk left/right and forward/back.
7. Confirm the light remains on the same physical wall spot.
8. Select a ceiling product.
9. Aim at ceiling.
10. Confirm it does not place on wall/floor.

## Pass Criteria

- Wall light attaches only to wall.
- Ceiling light attaches only to ceiling.
- Light does not follow screen center after placement.
- Light scale changes naturally as the camera moves.
- Light stays in place when walking around.

## Fail Causes

- Phone does not support ARKit/ARCore.
- Poor lighting.
- Blank wall with no visual features.
- App is not using AR anchors.
- Product model pivot is wrong.

## Model Requirements

Every fixture model should have:

- Correct real-world scale in meters.
- Pivot point at the mounting point.
- Forward direction facing away from wall for wall fixtures.
- Down direction correct for ceiling fixtures.
- Low polygon count for mobile.

