using UnityEngine;

namespace GlowNest.AR
{
    public class SurfaceReticle : MonoBehaviour
    {
        [SerializeField] private Transform ring;
        [SerializeField] private Transform wallMarker;
        [SerializeField] private Transform ceilingMarker;
        [SerializeField] private float smoothSpeed = 18f;

        private bool visible;
        private Pose targetPose;
        private MountType activeMountType;

        private void Awake()
        {
            SetVisible(false);
        }

        private void Update()
        {
            if (!visible)
                return;

            transform.SetPositionAndRotation(
                Vector3.Lerp(transform.position, targetPose.position, Time.deltaTime * smoothSpeed),
                Quaternion.Slerp(transform.rotation, targetPose.rotation, Time.deltaTime * smoothSpeed)
            );
        }

        public void Show(Pose pose, MountType mountType)
        {
            targetPose = pose;
            activeMountType = mountType;

            if (!visible)
            {
                transform.SetPositionAndRotation(pose.position, pose.rotation);
                SetVisible(true);
            }

            if (wallMarker != null)
                wallMarker.gameObject.SetActive(mountType == MountType.Wall);
            if (ceilingMarker != null)
                ceilingMarker.gameObject.SetActive(mountType == MountType.Ceiling);
            if (ring != null)
                ring.gameObject.SetActive(true);
        }

        public void SetVisible(bool state)
        {
            visible = state;
            if (ring != null)
                ring.gameObject.SetActive(state);
            if (wallMarker != null)
                wallMarker.gameObject.SetActive(state && activeMountType == MountType.Wall);
            if (ceilingMarker != null)
                ceilingMarker.gameObject.SetActive(state && activeMountType == MountType.Ceiling);
        }
    }
}

