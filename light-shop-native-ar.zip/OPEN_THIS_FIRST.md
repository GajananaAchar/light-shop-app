# Open This First

I prepared this as far as possible from this computer.

This machine does not have Unity, Android Studio, or Xcode available, so an APK/IPA cannot be built directly here. The project is ready for Unity.

## Fastest Use

1. Install Unity Hub.
2. Install Unity `2022.3 LTS`.
3. Include Android Build Support if you want Android.
4. Open this folder in Unity: `light-shop-native-ar`.
5. Wait for packages to install.
6. In Unity top menu, click `GlowNest > Build AR Scene`.
7. Open `Assets/Scenes/GlowNestAR.unity`.
8. For Android, click `GlowNest > Configure Android Build Notes`.
9. For iPhone, click `GlowNest > Configure iOS Build Notes`.

## What I Already Did

- Created Unity package manifest.
- Added AR Foundation scripts.
- Added wall/ceiling placement controller.
- Added AR anchor placement logic.
- Added catalog/product data.
- Added placeholder models and textures.
- Added one-click Unity scene builder.

## What Still Needs Unity

- Import AR Foundation packages.
- Generate the `.unity` scene through the menu.
- Build APK/AAB for Android.
- Export Xcode project for iPhone.

