using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

namespace GlowNest.AR
{
    [RequireComponent(typeof(ARRaycastManager))]
    public class ARPlacementController : MonoBehaviour
    {
        [Header("Scene References")]
        [SerializeField] private Camera arCamera;
        [SerializeField] private ProductCatalog catalog;
        [SerializeField] private ARPlaneManager planeManager;
        [SerializeField] private ARAnchorManager anchorManager;
        [SerializeField] private SurfaceReticle reticle;

        [Header("Placement")]
        [SerializeField] private float wallOffsetMeters = 0.018f;
        [SerializeField] private float ceilingOffsetMeters = 0.025f;
        [SerializeField] private float ceilingMinHeightAboveCamera = 0.45f;
        [SerializeField] private LayerMask placedObjectLayer = 0;

        private readonly List<ARRaycastHit> hits = new();
        private ARRaycastManager raycastManager;
        private GameObject placedObject;
        private ARAnchor placedAnchor;
        private LightProduct activeProduct;
        private bool hasValidTarget;
        private Pose lastValidPose;
        private ARPlane lastValidPlane;

        private void Awake()
        {
            raycastManager = GetComponent<ARRaycastManager>();
            if (arCamera == null)
                arCamera = Camera.main;
        }

        private void OnEnable()
        {
            if (catalog != null)
                catalog.ProductSelected += OnProductSelected;
        }

        private void OnDisable()
        {
            if (catalog != null)
                catalog.ProductSelected -= OnProductSelected;
        }

        private void Update()
        {
            UpdateTargetFromScreenCenter();

            if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
                TryPlaceSelectedLight();

#if UNITY_EDITOR
            if (Input.GetMouseButtonDown(0))
                TryPlaceSelectedLight();
#endif
        }

        private void OnProductSelected(LightProduct product)
        {
            activeProduct = product;
            RemovePlacedObject();
            SetPlaneVisibility(true);
        }

        private void UpdateTargetFromScreenCenter()
        {
            if (activeProduct == null || arCamera == null)
                return;

            Vector2 screenCenter = new(Screen.width * 0.5f, Screen.height * 0.5f);
            hasValidTarget = false;

            if (!raycastManager.Raycast(screenCenter, hits, TrackableType.PlaneWithinPolygon))
            {
                reticle?.SetVisible(false);
                return;
            }

            foreach (ARRaycastHit hit in hits)
            {
                ARPlane plane = planeManager != null ? planeManager.GetPlane(hit.trackableId) : null;
                if (plane == null || !IsPlaneAllowedForProduct(plane, activeProduct))
                    continue;

                Pose pose = BuildPlacementPose(hit.pose, plane, activeProduct);
                lastValidPose = pose;
                lastValidPlane = plane;
                hasValidTarget = true;
                reticle?.Show(pose, activeProduct.MountType);
                return;
            }

            reticle?.SetVisible(false);
        }

        private bool IsPlaneAllowedForProduct(ARPlane plane, LightProduct product)
        {
            Vector3 planeNormal = plane.transform.up;
            float verticality = Mathf.Abs(Vector3.Dot(planeNormal, Vector3.up));

            if (product.MountType == MountType.Wall)
                return verticality < 0.35f;

            if (product.MountType == MountType.Ceiling)
            {
                bool horizontal = verticality > 0.75f;
                bool aboveCamera = plane.center.y > arCamera.transform.position.y + ceilingMinHeightAboveCamera;
                bool normalLooksDownOrUp = Mathf.Abs(Vector3.Dot(planeNormal, Vector3.up)) > 0.75f;
                return horizontal && aboveCamera && normalLooksDownOrUp;
            }

            if (product.MountType == MountType.Strip)
                return verticality < 0.45f || verticality > 0.75f;

            return false;
        }

        private Pose BuildPlacementPose(Pose hitPose, ARPlane plane, LightProduct product)
        {
            Vector3 normal = plane.transform.up.normalized;

            if (product.MountType == MountType.Wall)
            {
                Vector3 outward = normal;
                if (Vector3.Dot(outward, arCamera.transform.position - hitPose.position) < 0f)
                    outward = -outward;

                Vector3 up = Vector3.up;
                Quaternion rotation = Quaternion.LookRotation(outward, up);
                Vector3 position = hitPose.position + outward * wallOffsetMeters;
                return new Pose(position, rotation);
            }

            if (product.MountType == MountType.Ceiling)
            {
                Vector3 down = Vector3.down;
                Vector3 forward = Vector3.ProjectOnPlane(arCamera.transform.forward, Vector3.up).normalized;
                if (forward.sqrMagnitude < 0.01f)
                    forward = Vector3.forward;

                Quaternion rotation = Quaternion.LookRotation(forward, down);
                Vector3 position = hitPose.position + down * ceilingOffsetMeters;
                return new Pose(position, rotation);
            }

            Quaternion stripRotation = Quaternion.LookRotation(arCamera.transform.forward, Vector3.up);
            return new Pose(hitPose.position, stripRotation);
        }

        public void TryPlaceSelectedLight()
        {
            if (!hasValidTarget || activeProduct == null || catalog == null)
                return;

            RemovePlacedObject();

            GameObject model = catalog.CreateSelectedModel();
            if (model == null)
                return;

            placedAnchor = CreateAnchor(lastValidPose, lastValidPlane);
            Transform parent = placedAnchor != null ? placedAnchor.transform : transform;

            placedObject = model;
            placedObject.transform.SetParent(parent, worldPositionStays: false);
            placedObject.transform.localPosition = Vector3.zero;
            placedObject.transform.localRotation = Quaternion.identity;
            ApplyProductScale(placedObject.transform, activeProduct);
            SetPlaneVisibility(false);
        }

        private ARAnchor CreateAnchor(Pose pose, ARPlane plane)
        {
            if (anchorManager == null)
                return null;

            ARAnchor anchor = anchorManager.AttachAnchor(plane, pose);
            if (anchor != null)
                return anchor;

            GameObject anchorObject = new("Light Anchor");
            anchorObject.transform.SetPositionAndRotation(pose.position, pose.rotation);
            return anchorObject.AddComponent<ARAnchor>();
        }

        private void ApplyProductScale(Transform model, LightProduct product)
        {
            float targetWidth = Mathf.Max(0.05f, product.widthMeters);
            Bounds bounds = CalculateBounds(model);
            if (bounds.size.x <= 0.001f && bounds.size.y <= 0.001f)
                return;

            float currentWidth = Mathf.Max(bounds.size.x, bounds.size.z);
            if (product.MountType == MountType.Wall)
                currentWidth = Mathf.Max(bounds.size.x, bounds.size.y * 0.5f);

            float scale = targetWidth / Mathf.Max(0.001f, currentWidth);
            model.localScale *= scale;
        }

        private Bounds CalculateBounds(Transform root)
        {
            Renderer[] renderers = root.GetComponentsInChildren<Renderer>();
            if (renderers.Length == 0)
                return new Bounds(root.position, Vector3.one);

            Bounds bounds = renderers[0].bounds;
            for (int i = 1; i < renderers.Length; i++)
                bounds.Encapsulate(renderers[i].bounds);

            return bounds;
        }

        public void RemovePlacedObject()
        {
            if (placedObject != null)
                Destroy(placedObject);
            if (placedAnchor != null)
                Destroy(placedAnchor.gameObject);

            placedObject = null;
            placedAnchor = null;
            SetPlaneVisibility(true);
        }

        private void SetPlaneVisibility(bool visible)
        {
            if (planeManager == null)
                return;

            foreach (ARPlane plane in planeManager.trackables)
                plane.gameObject.SetActive(visible);
        }
    }
}

