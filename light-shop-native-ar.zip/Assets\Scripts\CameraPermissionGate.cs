using System.Collections;
using UnityEngine;

namespace GlowNest.AR
{
    public class CameraPermissionGate : MonoBehaviour
    {
        [SerializeField] private GameObject permissionPanel;
        [SerializeField] private GameObject arRoot;

        private IEnumerator Start()
        {
#if UNITY_ANDROID || UNITY_IOS
            if (!Application.HasUserAuthorization(UserAuthorization.WebCam))
            {
                permissionPanel?.SetActive(true);
                arRoot?.SetActive(false);
                yield return Application.RequestUserAuthorization(UserAuthorization.WebCam);
            }
#else
            yield return null;
#endif

            bool allowed = Application.HasUserAuthorization(UserAuthorization.WebCam);
            permissionPanel?.SetActive(!allowed);
            arRoot?.SetActive(allowed);
        }
    }
}

