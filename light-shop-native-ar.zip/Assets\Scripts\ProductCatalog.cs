using System;
using System.Collections.Generic;
using UnityEngine;

namespace GlowNest.AR
{
    public class ProductCatalog : MonoBehaviour
    {
        [SerializeField] private string resourceName = "products";
        [SerializeField] private ProductModelLibrary modelLibrary;

        private readonly List<LightProduct> products = new();
        private int selectedIndex;

        public IReadOnlyList<LightProduct> Products => products;
        public LightProduct SelectedProduct => products.Count == 0 ? null : products[selectedIndex];
        public event Action<LightProduct> ProductSelected;

        private void Awake()
        {
            LoadProducts();
        }

        public void LoadProducts()
        {
            products.Clear();
            TextAsset json = Resources.Load<TextAsset>(resourceName);
            if (json == null)
            {
                Debug.LogError($"Product catalog JSON '{resourceName}' was not found in Resources.");
                return;
            }

            LightProductCollection collection = JsonUtility.FromJson<LightProductCollection>(json.text);
            if (collection?.products == null)
            {
                Debug.LogError("Product catalog JSON is invalid.");
                return;
            }

            products.AddRange(collection.products);
            selectedIndex = Mathf.Clamp(selectedIndex, 0, Mathf.Max(0, products.Count - 1));
            ProductSelected?.Invoke(SelectedProduct);
        }

        public void SelectProduct(string productId)
        {
            int index = products.FindIndex(product => product.id == productId);
            if (index < 0)
            {
                Debug.LogWarning($"Product '{productId}' was not found.");
                return;
            }

            selectedIndex = index;
            ProductSelected?.Invoke(SelectedProduct);
        }

        public GameObject CreateSelectedModel()
        {
            if (SelectedProduct == null || modelLibrary == null)
                return null;

            return modelLibrary.CreateModel(SelectedProduct);
        }
    }
}

