# Developer Brief

## Vision

The customer should not feel like a light sticker is following the phone screen. The light must be placed on a real detected wall or ceiling, saved as a world anchor, and rendered from the correct perspective while the customer walks around.

## Core Technical Theory

Normal camera video is 2D. It cannot know the exact wall distance by itself. Real AR uses SLAM: simultaneous localization and mapping. The phone combines camera frames, gyroscope, accelerometer, and feature tracking to build a 3D understanding of the room.

The app must use:

- Plane detection: detect vertical walls and horizontal ceilings.
- Raycast: cast from screen center or user tap to a real AR plane.
- Anchor: save the light at that world transform.
- Surface filtering: reject wrong surfaces.
- Real 3D rendering: use 3D light models instead of flat stickers.

## Placement Rules

Wall light:

- Use only vertical planes.
- Rotate object so its forward direction faces away from the wall.
- Keep it flush on the wall with a small offset to avoid z-fighting.

Ceiling light:

- Use only horizontal planes above the camera height when possible.
- Rotate object downward.
- Keep pendant/chandelier centered on ceiling plane hit.

LED strip:

- Use upper wall/ceiling boundary.
- Can be represented as an adjustable-length strip in a later version.

## Why Web Was Not Perfect

The web version tracks pixels. If the customer moves, lighting changes, the wall is plain, or the camera loses texture, the app cannot know the real 3D point. Native AR stores the light in world coordinates, so it stays in place.

## Implementation Choice

Use Unity + AR Foundation first. It is the most practical path for one team to ship both platforms.

Alternative:

- Native iPhone: Swift + ARKit + RealityKit
- Native Android: Kotlin + ARCore + Filament

Unity is recommended because it shares almost all AR logic and catalog logic.

## Production Tasks

1. Replace placeholder GLB files with high-quality optimized real fixture models.
2. Create Unity prefabs for each product.
3. Build catalog UI with product cards and try-in action.
4. Add real AR scene with surface reticle.
5. Add screenshot/share/customer inquiry flow.
6. Test on real iPhone and Android devices.

