using System;
using UnityEngine;

namespace GlowNest.AR
{
    public enum MountType
    {
        Wall,
        Ceiling,
        Strip
    }

    [Serializable]
    public class LightProduct
    {
        public string id;
        public string name;
        public string category;
        public string type;
        public string price;
        public string model;
        public string image;
        public string mount;
        public float widthMeters;
        public float heightMeters;
        public string description;

        public MountType MountType
        {
            get
            {
                if (string.Equals(mount, "wall", StringComparison.OrdinalIgnoreCase))
                    return MountType.Wall;
                if (string.Equals(mount, "strip", StringComparison.OrdinalIgnoreCase))
                    return MountType.Strip;
                return MountType.Ceiling;
            }
        }
    }

    [Serializable]
    public class LightProductCollection
    {
        public LightProduct[] products;
    }
}

