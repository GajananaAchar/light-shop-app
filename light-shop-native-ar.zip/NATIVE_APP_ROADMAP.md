# Native App Roadmap

## Phase 1: Real AR Proof

- Unity AR Foundation scene.
- Plane detection.
- Wall/ceiling filtering.
- One wall light.
- One ceiling light.
- Real anchor placement.

## Phase 2: Shop Catalog

- Product categories.
- Product details.
- Search/filter.
- Pricing.
- Try in room button.

## Phase 3: Better Realism

- Replace placeholder models with final 3D models.
- Add warm emissive materials.
- Add fake area glow.
- Add contact shadows.
- Tune scale per product.

## Phase 4: Business Features

- WhatsApp inquiry.
- Save screenshot.
- Share preview.
- Favorite products.
- Stock/admin product update flow.

## Phase 5: Store Release

- Android APK/AAB.
- iOS TestFlight.
- App Store assets.
- Privacy policy.
- Camera permission descriptions.

