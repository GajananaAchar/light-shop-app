# GlowNest Native AR App

This folder is the production direction for the lights-shop app: a Unity + AR Foundation mobile project for both iPhone and Android.

The website demo can only estimate movement from camera pixels. This native app direction uses phone AR systems:

- iPhone: ARKit through AR Foundation
- Android: ARCore through AR Foundation
- Shared app code: Unity C#

## What The App Should Do

1. Show a mobile light catalog.
2. Customer selects a wall light or ceiling light.
3. Camera opens in AR mode.
4. The phone scans real surfaces.
5. Wall lights attach only to vertical wall planes.
6. Ceiling lights attach only to upper horizontal planes.
7. Once placed, the light stays fixed to the real room, not to the screen.
8. When the customer moves closer or farther, AR perspective changes naturally.

## Folder Contents

- `Assets/Scripts`: Unity C# scripts for catalog, AR placement, and product loading.
- `Assets/Resources/products.json`: Product data used by the catalog.
- `Assets/Models`: GLB model placeholders copied from the web app.
- `Assets/Textures`: Product images copied from the web app.
- `Packages/manifest.json`: Unity package dependencies.
- `DEVELOPER_BRIEF.md`: Plain-English build explanation.

## Build Requirements

- Unity 2022 LTS or newer
- AR Foundation
- ARKit XR Plugin for iPhone
- ARCore XR Plugin for Android
- iPhone build requires macOS + Xcode
- Android build requires Android SDK/NDK

## Best Next Step

Open this folder as a Unity project, install the listed packages, create one scene, add `AR Session`, `XR Origin`, `ARRaycastManager`, `ARPlaneManager`, and attach `ARPlacementController`.

